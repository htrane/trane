<?php
class HomeModel extends DB {
    // Lấy tất cả sản phẩm
    public function getProducts() : array {
        $sql = "SELECT * FROM adproduct";
        $stm = $this->con->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getProductById($id) {
        $sql = "SELECT * FROM adproduct WHERE ma_sp = :id"; // Giả sử "ma_sp" là khóa chính
        $stmt = $this->con->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC); // Trả về một mảng sản phẩm hoặc null
    }
    // tìm kiếm theo danh mục
    public function getProductsByCategory($category) {
        $sql = "SELECT * FROM adproduct WHERE Ten_loaisp = :category";
        $stm = $this->con->prepare($sql);
        $stm->bindParam(':category', $category);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // tìm kiếm theo mã or tên loại sp
    public function searchProducts($txt_search) {
        // Đảm bảo giá trị tìm kiếm được bảo vệ
        $txt_search = "%" . $txt_search . "%"; // Thêm ký tự % để tìm kiếm như LIKE
    
        // Bắt đầu với câu lệnh SQL với tham số
        $sql = "SELECT * FROM adproduct WHERE (Ten_loaisp LIKE :search OR ma_sp LIKE :search)"; // Sử dụng LIKE cho cả hai trường
    
        $stm = $this->con->prepare($sql);
        $stm->bindParam(':search', $txt_search); // Ràng buộc tham số an toàn
        $stm->execute();
        
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
    
}
