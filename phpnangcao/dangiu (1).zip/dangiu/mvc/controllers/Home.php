<?php
class Home extends Controller {
    public function getShow() {
        // Lấy dữ liệu từ Model
        $homeModel = $this->model("HomeModel");
        $products = $homeModel->getProducts();

        // Kiểm tra tìm kiếm
        if (isset($_POST['search'])) {
            $searchKeyword = $_POST['txt_search'];
            $categoryFilter = isset($_POST['category']) ? $_POST['category'] : '';
            $products = $homeModel->searchProducts($searchKeyword, $categoryFilter);
        }

        // Gọi View để hiển thị 
        $this->view("HomeView", ["page" => "Home", "products" => $products]);
    }

    public function searchProducts(){
        $adProductModel = $this->model("HomeModel");
        $seachProdcut = $adProductModel->searchProducts();
        $this->view("HomeView", ["page" => "Home", "seachProdcut" => $seachProdcut]);
    }

    
    public function getDetailsProduct($id) {
        // Lấy mô hình sản phẩm
        $adProductModel = $this->model("HomeModel");
        
        // Kiểm tra xem ID có tồn tại hay không
        if (!$id) {
            // Nếu không có ID, chuyển hướng về hàm getShow
            header("Location: " . BASE_URL . "Home/getShow");
            exit; // Dừng thực thi script sau khi chuyển hướng
        }
    
        // Lấy thông tin sản phẩm theo ID
        $productDetail = $adProductModel->getProductById($id);
        
        // Kiểm tra xem sản phẩm có tồn tại không
        if ($productDetail) {
            // Nếu tồn tại, gán dữ liệu vào mảng và hiển thị view chi tiết sản phẩm
            $data["product"] = $productDetail; // Chỉ cần dùng "product" vì đây là một sản phẩm duy nhất
            $data["page"] = "Details_Product";
            $this->view("HomeView", $data);
        } else {
            // Nếu không tồn tại, chuyển hướng về trang chính với thông báo
            $_SESSION['error_message'] = "Sản phẩm không tồn tại.";
            header("Location: " . BASE_URL . "Home/getShow");
            exit;
        }
    }
}
