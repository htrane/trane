<div class="main">
    <!-- code header -->
    <div class="header2">
        <nav>
            <ul class="menu1">
                <li><a class="a-header" href="<?php echo BASE_URL . 'Home/getShow'; ?>" style="color: black;">Trang chủ</a></li>
                <li class="dropdown">
                    <a class="a-header dropdown-btn" href="#">Sản phẩm</a>
                    <div class="dropdown-content">
                        <?php
                        // Kiểm tra có bản ghi nào trong danh sách sản phẩm hay không
                        if (!empty($data["products"])) {
                            // Lặp qua các sản phẩm và lấy ra danh mục
                            foreach ($data["products"] as $product) {
                                echo "<a class='a-header' href='#'>" . $product['Ten_loaisp'] . "</a>";
                            }
                        } else {
                        }
                        ?>
                    </div>
                </li>
                <li><a class="a-header" href="#" style="color: black;">Tin tức</a></li>
                <li><a class="a-header" href="#" style="color: black;">Góp ý</a></li>
                <li><a class="a-header" href="#" style="color: black;">Đơn hàng</a></li>
                <li><a class="a-header" href="#" style="color: black;">Lịch sử mua hàng</a></li>
                <li><a class="a-header" href="#" style="color: black;">Giỏ hàng</a></li>
            </ul>
        </nav>
        <div id="slide">
            <a href="#"><img src="../public/images/GiaoDienNen.jpg" alt=""></a>
        </div>
    </div>
</div>
