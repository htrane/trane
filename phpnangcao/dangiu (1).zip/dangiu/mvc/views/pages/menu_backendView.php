<div class="header">
    <div class="header1">
        <h1>Trang quản trị</h1>
    </div>
    <div class="header2">
        <ul class="menu1 mainmenu">
            <li><a class="menu1" href="./AdProductType/">Quản lý loại sản phẩm</a></li>
            <li><a class="menu1" href="./AdProduct/">Quản lý sản phẩm</a></li>
            <li><a class="menu1" href="./QuanlyKhachHang/">Quản lý khách hàng</a></li>
            <li><a class="menu1" href="#">Quản lý đơn hàng</a></li>
            <li><a class="menu1" href="#">Quản lý doanh thu</a></li>
        </ul>
    </div>
</div>
