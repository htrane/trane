<?php
    echo "ok";
?>