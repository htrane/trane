

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Sản Phẩm</title>
    <link rel="stylesheet" href="../public/styles/styleHome.css">
</head>
<body>
    <div class="container">
        <h1>Chi Tiết Sản Phẩm</h1>

        <div class="product-detail">
            <?php if (!empty($data['product'])): ?>
                <?php
                $product = $data['product'];
                $gia_xuat = $product['giaxuat'];
                $khuyenmai = $product['khuyenmai'];
                $gia_ban = $gia_xuat - ($gia_xuat * $khuyenmai / 100);
                $mo_ta = $product['Mota_loaisp'];
                ?>
                    <td><img src="../public/images/<?php echo $r['hinhanh']; ?>" width="50" height="50"></td> <!-- Sửa lại cú pháp -->
                    <h2><?php echo $product['Ten_loaisp']; ?></h2>

                <?php if ($khuyenmai > 0): ?>
                    <p><strong>Giá bán:</strong> <del><?php echo $gia_xuat; ?> VND</del></p>
                    <p><strong>Khuyến mãi:</strong> <?php echo $khuyenmai; ?>%</p>
                    <p><strong>Giảm giá còn:</strong> <?php echo $gia_ban; ?> VND</p>
                    <p><strong>Mô tả:</strong> <?php echo $mo_ta; ?></p>
                <?php else: ?>
                    <p><strong>Giá bán:</strong> <?php echo $gia_xuat; ?> VND</p>
                <?php endif; ?>
            <?php else: ?>
                <p>Sản phẩm không tồn tại.</p>
            <?php endif; ?>
        </div>

        <div class="back-link">
            <a href="<?php echo BASE_URL . 'Home/getShow'; ?>">Quay lại trang chủ</a>
        </div>
    </div>
</body>
</html>
