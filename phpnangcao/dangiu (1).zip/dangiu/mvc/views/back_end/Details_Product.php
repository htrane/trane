<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Sản Phẩm</title>
    <link href="<?php echo BASE_URL . 'public/styles/styleHome.css'; ?>" rel="stylesheet"/>
</head>
<body>
    <div class="container">
        <h1>Chi Tiết Sản Phẩm</h1>
        <form action="Home/getShow" method="get">
            <div class="product-detail">
                <?php if (!empty($data['product'])): ?>
                    <?php
                    $product = $data['product'];
                    $gia_xuat = $product['giaxuat'];
                    $khuyenmai = $product['khuyenmai'];
                    $gia_ban = $gia_xuat - ($gia_xuat * $khuyenmai / 100);
                    $mo_ta = $product['Mota_loaisp'];
                    ?>
                    <!-- Hiển thị hình ảnh sản phẩm -->
                    <div>
                        <img class="product-image" src="<?php echo BASE_URL . 'public/images/' . $data['product']['hinhanh']; ?>" alt="Hình ảnh sản phẩm">
                    </div>
                    
                    <!-- Hiển thị tên sản phẩm -->
                    <h2><?php echo $product['Ten_loaisp']; ?></h2>

                    <!-- Hiển thị chi tiết giá và khuyến mãi -->
                    <?php if ($khuyenmai > 0): ?>
                        <p class="discount-price">Giá bán: <del><?php echo $gia_xuat; ?> VND</del></p>
                        <p class="price">Giảm giá còn: <?php echo $gia_ban; ?> VND</p>
                        <p><strong>Khuyến mãi:</strong> <?php echo $khuyenmai; ?>%</p>
                        <p><strong>Mô tả:</strong> <?php echo $mo_ta; ?></p>
                    <?php else: ?>
                        <p class="price">Giá bán: <?php echo $gia_xuat; ?> VND</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p>Sản phẩm không tồn tại.</p>
                <?php endif; ?>
            </div>
        </form>

        <div class="back-link">
            <a href="<?php echo BASE_URL . 'Home/getShow'; ?>">Quay lại trang chủ</a>
        </div>
    </div>
</body>
</html>
