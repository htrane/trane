<?php
    echo "Trang quản trị";

?>